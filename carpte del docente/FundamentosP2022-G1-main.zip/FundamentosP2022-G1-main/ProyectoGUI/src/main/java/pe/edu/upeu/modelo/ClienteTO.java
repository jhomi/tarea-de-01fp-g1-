package pe.edu.upeu.modelo;

import lombok.Getter;
import lombok.Setter;

@Setter @Getter
public class ClienteTO {
   public String dni, nombre;
}
